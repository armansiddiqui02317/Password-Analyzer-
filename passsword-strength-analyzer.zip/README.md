# Password Strength Analyzer

A beginner-friendly cybersecurity project that analyzes password length, complexity, common-password usage, and repeated patterns.

## Features
- Password length check
- Uppercase/lowercase/number/special-character checks
- Common-password detection
- Repeated-character detection
- Strength score and meter
- Security recommendations
- Strong password generator
- Show/hide and copy controls
- Password analysis runs locally in the browser

## Run

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

## Important security note

This educational version does not store passwords or send them to a backend. For a real authentication system, passwords should be handled using established password hashing methods such as Argon2id or bcrypt and should never be stored as plaintext.
