import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const commonPasswords = new Set([
  "password", "password123", "123456", "12345678", "123456789",
  "qwerty", "qwerty123", "admin", "admin123", "letmein",
  "welcome", "iloveyou", "abc123", "000000", "111111"
]);

function analyzePassword(password) {
  const checks = {
    length: password.length >= 12,
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    number: /\d/.test(password),
    special: /[^A-Za-z0-9]/.test(password),
    common: !commonPasswords.has(password.toLowerCase()),
    repeated: !/(.)\1\1/.test(password),
  };

  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (password.length >= 16) score++;
  if (checks.uppercase) score++;
  if (checks.lowercase) score++;
  if (checks.number) score++;
  if (checks.special) score++;
  if (checks.common) score++;
  if (checks.repeated) score++;

  let level = "Very Weak";
  if (score >= 8) level = "Very Strong";
  else if (score >= 6) level = "Strong";
  else if (score >= 4) level = "Medium";
  else if (score >= 2) level = "Weak";

  const suggestions = [];
  if (password.length < 12) suggestions.push("Use at least 12 characters.");
  if (!checks.uppercase) suggestions.push("Add uppercase letters (A-Z).");
  if (!checks.lowercase) suggestions.push("Add lowercase letters (a-z).");
  if (!checks.number) suggestions.push("Add numbers (0-9).");
  if (!checks.special) suggestions.push("Add special characters such as @, #, ! or $.");
  if (!checks.common) suggestions.push("Avoid common passwords.");
  if (!checks.repeated) suggestions.push("Avoid repeated characters such as aaa or 111.");

  return { checks, score: Math.min(score, 9), level, suggestions };
}

function generatePassword() {
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const numbers = "23456789";
  const special = "!@#$%^&*";
  const all = upper + lower + numbers + special;

  const randomChar = (set) => set[Math.floor(Math.random() * set.length)];
  let result = randomChar(upper) + randomChar(lower) + randomChar(numbers) + randomChar(special);
  for (let i = result.length; i < 16; i++) result += randomChar(all);
  return result.split("").sort(() => Math.random() - 0.5).join("");
}

function App() {
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);

  const result = useMemo(() => analyzePassword(password), [password]);
  const percent = password ? Math.round((result.score / 9) * 100) : 0;

  const copyPassword = async () => {
    if (!password) return;
    await navigator.clipboard.writeText(password);
  };

  const useGenerated = () => setPassword(generatePassword());

  return (
    <main className="page">
      <section className="app">
        <div className="hero">
          <div className="badge">CYBER SECURITY TOOL</div>
          <h1>Password Strength <span>Analyzer</span></h1>
          <p>Check password security locally and get practical recommendations.</p>
        </div>

        <div className="input-card">
          <label htmlFor="password">Enter password</label>
          <div className="input-row">
            <input
              id="password"
              type={show ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Type a password to analyze..."
              autoComplete="off"
            />
            <button className="secondary" onClick={() => setShow(!show)}>
              {show ? "Hide" : "Show"}
            </button>
          </div>

          <div className="actions">
            <button className="primary" onClick={useGenerated}>Generate Strong Password</button>
            <button className="secondary" onClick={copyPassword} disabled={!password}>Copy</button>
          </div>
          <p className="privacy">🔒 Analysis happens in your browser. The password is not sent to a server.</p>
        </div>

        <div className="result-card">
          <div className="result-head">
            <div>
              <span className="muted">Strength</span>
              <h2>{password ? result.level : "Waiting for password"}</h2>
            </div>
            <div className="score">{password ? `${result.score}/9` : "—"}</div>
          </div>

          <div className="meter">
            <div style={{ width: `${percent}%` }}></div>
          </div>

          <div className="checks">
            {[
              ["length", "At least 12 characters"],
              ["uppercase", "Uppercase letter"],
              ["lowercase", "Lowercase letter"],
              ["number", "Number"],
              ["special", "Special character"],
              ["common", "Not a common password"],
              ["repeated", "No repeated character pattern"]
            ].map(([key, label]) => (
              <div className={`check ${password && result.checks[key] ? "pass" : ""}`} key={key}>
                <span>{password && result.checks[key] ? "✓" : "○"}</span>
                {label}
              </div>
            ))}
          </div>
        </div>

        <div className="suggestion-card">
          <h3>Security recommendations</h3>
          {!password ? (
            <p>Enter a password to see recommendations.</p>
          ) : result.suggestions.length === 0 ? (
            <p className="success">✓ No basic weaknesses detected. Still avoid reusing this password on other sites.</p>
          ) : (
            <ul>{result.suggestions.map((s) => <li key={s}>{s}</li>)}</ul>
          )}
        </div>

        <footer>
          Password Strength Analyzer • Educational cybersecurity project
        </footer>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
